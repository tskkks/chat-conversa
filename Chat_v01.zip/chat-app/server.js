// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Servir os arquivos estáticos na pasta 'public'
app.use(express.static('public'));

// Configurar o Socket.IO para o evento de conexão
io.on('connection', (socket) => {
  console.log('Um usuário se conectou');

  // Recebe mensagem do cliente e emite para todos os clientes conectados
  socket.on('chat message', (msg) => {
    io.emit('chat message', msg);
  });

  // Log de desconexão
  socket.on('disconnect', () => {
    console.log('Usuário desconectado');
  });
});

server.listen(4000, () => {
    console.log('Servidor rodando em http://localhost:4000');
  });
  